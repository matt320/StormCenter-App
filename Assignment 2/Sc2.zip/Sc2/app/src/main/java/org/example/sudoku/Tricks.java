package org.example.sudoku;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Matthew on 7/12/2015.
 */
public class Tricks extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tricks);
    }
}
