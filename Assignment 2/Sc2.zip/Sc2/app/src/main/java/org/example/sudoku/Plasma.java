package org.example.sudoku;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.app.Activity;
/**
 * Created by Matthew on 7/10/2015.
 */
public class Plasma extends Activity  {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.plasmaball);
    }

    }



